﻿// Age of Empires II HD Edition Client.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include <iostream>

int main()
{
    int user;
    std::cin >> user;
    std::cout << user+"is.";
    //set a game
    int set;
    std::cin >> set;
    std::cout << set;
    //gaming
    int bulid;
    int unit;
    int senice;
    double level;
    
    return 1;
}




